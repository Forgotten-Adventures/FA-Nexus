import { createFolderSelectionPredicate } from '../content/content-sources/content-sources-utils.js';
import { GridBrowseTab } from '../core/ui/grid-browse-tab.js';
import { applyGridDensityStyles } from '../core/ui/grid-density-styles.js';
import { NexusLogger as Logger } from '../core/nexus-logger.js';
import { AssetPreviewManager } from './assets-preview-manager.js';
import { NexusContentService, getEnabledFolders } from '../content/nexus-content-service.js';
import {
  applyFolderBrowserSelectionChange,
  createEmptyFolderBrowserStats,
  readFolderBrowserSelection
} from '../core/folder-browser-state.js';
import { AssetsTabController } from './assets-tab-controller.js';
import {
  contentFilename,
  contentFolder,
  contentGrid,
  contentPath
} from '../content/cloud-inventory-v2.js';
import { AssetsTabSelectionHelper } from './assets-selection-helper.js';
import { AssetsTabProbeHelper } from './assets-probe-helper.js';
import { AssetsTabCardHelper } from './assets-card-helper.js';
import { hasContentProductAccess, lockedPremiumContentMessage } from '../premium/patreon-auth-contract.js';

const SOLID_TEXTURE_ITEM_ID = '__fa-nexus-solid-color';
const SOLID_TEXTURE_DEFAULT_COLOR = '#808080';
const SOLID_TEXTURE_SIZE = 200;

const normalizeSolidTextureColor = (value) => {
  if (typeof value !== 'string') return SOLID_TEXTURE_DEFAULT_COLOR;
  const trimmed = value.trim();
  const full = /^#([0-9a-f]{6})$/i.exec(trimmed);
  if (full) return `#${full[1].toLowerCase()}`;
  const short = /^#([0-9a-f]{3})$/i.exec(trimmed);
  if (short) {
    const [r, g, b] = short[1].split('');
    return `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
  }
  return SOLID_TEXTURE_DEFAULT_COLOR;
};

const buildSolidTextureDataUrl = (color) => {
  if (!globalThis?.document?.createElement) return '';
  const canvas = document.createElement('canvas');
  canvas.width = SOLID_TEXTURE_SIZE;
  canvas.height = SOLID_TEXTURE_SIZE;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  ctx.fillStyle = normalizeSolidTextureColor(color);
  ctx.fillRect(0, 0, SOLID_TEXTURE_SIZE, SOLID_TEXTURE_SIZE);
  return canvas.toDataURL('image/png');
};

const normalizeFaNexusModulePath = (value) => {
  const raw = String(value || 'modules/fa-nexus').replace(/^https?:\/\/[^/]+/i, '');
  return raw.replace(/^\/+/, '').replace(/\/+$/, '') || 'modules/fa-nexus';
};

/**
 * AssetsTab
 * Local assets browser tab with virtualized grid, per‑tab search and thumbnail sizing,
 * throttled image loading, hover preview, and click‑to‑place tile placement.
 */
export class AssetsTab extends GridBrowseTab {
  /**
   * @param {import('../nexus-app.js').FaNexusApp} app
   */
  constructor(app, options = {}) {
    super(app);
    this._controller = new AssetsTabController(this, options);
    this._loadId = 0;
    this._boundSettingsChange = null;
    // Cloud integration
    this._cloudAbort = null;
    this._indexingLocks = 0;
    this._selection = new AssetsTabSelectionHelper(this);
    this._probe = new AssetsTabProbeHelper(this);
    this._cards = new AssetsTabCardHelper(this);
    // Deferred cache-state probing (run when scrolling stops)
    this._pendingProbeAfterThumbAdjust = false;
    this._deferredActivationTimeout = null;
    this._needsReload = false;
    this._didDeactivate = false;
    this._dropShadowUpdateHandler = null;
    const requestedMode = String(options?.mode || 'assets').toLowerCase();
    this._mode = ['textures', 'paths'].includes(requestedMode) ? requestedMode : 'assets';
    this._activeFolderSelection = { type: 'all', includePaths: [], includePathLowers: [] };
    this._folderStats = createEmptyFolderBrowserStats();
    this._solidTextureItem = null;
  }

  get id() { return this._mode; }

  get isTexturesMode() { return this._mode === 'textures'; }

  get isPathsMode() { return this._mode === 'paths'; }

  get asyncSearchThreshold() { return 50000; }

  get placementManager() {
    return this._controller?.placementManager || this._placement || null;
  }

  get texturePaintManager() {
    return this._controller?.texturePaintManager || this._texturePaint || null;
  }

  get pathManagerV2() {
    return this._controller?.pathManagerV2 || this._pathManagerV2 || null;
  }

  get contentService() {
    return this._controller?.contentService || this._content || null;
  }

  get downloadManager() {
    return this._controller?.downloadManager || this._download || null;
  }

  get assetsService() {
    return this._controller?.assetsService || this._assets || null;
  }

  get thumbSliderMin() { return 54; }
  get thumbSliderMax() { return 108; }
  get thumbSliderStep() { return 2; }
  get thumbSliderDefault() { return 72; }

  _getThumbSettingKey() {
    return this.isTexturesMode ? 'thumbWidthTextures' : this.isPathsMode ? 'thumbWidthPaths' : 'thumbWidthAssets';
  }

  _sanitizeThumbSize(value) {
    const min = this.thumbSliderMin;
    const max = this.thumbSliderMax;
    const fallback = this.thumbSliderDefault;
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }

  _getStoredThumbSize() {
    const fallback = this.thumbSliderDefault;
    let scoped = 0;
    let global = 0;
    try {
      const key = this._getThumbSettingKey();
      scoped = Number(game.settings.get('fa-nexus', key) || 0) || 0;
    } catch (_) {}
    if (!scoped) {
      try {
        global = Number(game.settings.get('fa-nexus', 'thumbWidth') || 0) || 0;
      } catch (_) {}
    }
    const stored = scoped || global || fallback;
    return this._sanitizeThumbSize(stored);
  }

  _reportAssetPlacementFailure(scope, error, details = {}) {
    if (error && typeof error === 'object' && error.__faNexusAssetPlacementReported) return;
    if (error && typeof error === 'object') {
      try {
        Object.defineProperty(error, '__faNexusAssetPlacementReported', {
          value: true,
          configurable: true
        });
      } catch (_) {}
    }
    const message = String(error?.message || error || 'Unknown asset placement error');
    Logger.error(scope, { ...details, error: message });
    try { ui.notifications?.error?.(`Unable to start asset placement: ${message}`); } catch (_) {}
  }

  _usesWidePathThumbs() {
    return this.isPathsMode;
  }

  _getThumbAspectRatio() {
    return this._usesWidePathThumbs() ? 3 : 1;
  }

  /**
   * Convert a slider value into actual card dimensions, keeping path thumbnails wide.
   * @param {number} sliderValue
   * @returns {{width:number,height:number}}
   */
  _computeThumbDimensions(sliderValue) {
    const base = Math.max(1, Math.round(sliderValue));
    const ratio = Math.max(0.1, Number(this._getThumbAspectRatio()) || 1);
    if (ratio === 1) return { width: base, height: base };
    if (ratio > 1) return { width: Math.round(base * ratio), height: base };
    return { width: base, height: Math.round(base / ratio) };
  }

  getPlaceholderCardSize() {
    const base = super.getPlaceholderCardSize();
    const app = this.app;
    const defaultGap = this.getGridOptions?.()?.card?.gap ?? base.gap;
    const stored = this._getStoredThumbSize();
    const dims = this._computeThumbDimensions(stored);
    const gap = Math.max(2, Math.round(defaultGap || 4));
    if (app?._grid?.card) {
      return {
        width: Math.round(app._grid.card.width),
        height: Math.round(app._grid.card.height),
        gap
      };
    }
    return {
      width: Math.round(dims.width),
      height: Math.round(dims.height),
      gap
    };
  }

  /**
   * VirtualGrid options for asset cards
   * @returns {{rowHeight:number,overscan:number,card:{width:number,height:number,gap:number},createRow:function,onMountItem:function,onUnmountItem:function}}
   */
  getGridOptions() {
    const self = this;
    const stored = this._getStoredThumbSize();
    const dims = this._computeThumbDimensions(stored);
    return {
      rowHeight: 40,
      overscan: 5,
      card: { width: dims.width || 140, height: dims.height || 140, gap: 4 },
      createRow: (item) => self._createAssetCard(item),
      onMountItem: (el, item) => self._mountAssetCard(el, item),
      onUnmountItem: (el) => self._unmountAssetCard(el)
    };
  }

  supportsFolderBrowser() {
    return true;
  }

  getActiveFolderSelection() {
    return readFolderBrowserSelection({
      selection: this._activeFolderSelection,
      normalizePath: (value) => this._normalizeFolderPath(value),
      logger: Logger,
      loggerLabel: 'AssetsTab.selection.getActiveFolderSelection'
    });
  }

  onFolderSelectionChange(selection) {
    applyFolderBrowserSelectionChange({
      app: this.app,
      tabId: this.id,
      selection,
      normalizePath: (value) => this._normalizeFolderPath(value),
      logger: Logger,
      loggerLabel: 'AssetsTab.selection.normalize',
      enabled: this.supportsFolderBrowser(),
      getSelection: () => this._activeFolderSelection,
      setSelection: (nextSelection) => {
        this._activeFolderSelection = nextSelection;
      },
      beforeSync: () => {
        // Filter the grid first for immediate visual feedback
        this.applySearch(this.getCurrentSearchValue());
      }
    });
  }

  /** Track the visible list for range-selection and refresh selection UI */
  afterApplySearch(filtered, _query) {
    super.afterApplySearch(filtered, _query);
    try { this._selection.resetVisibleItems(filtered); } catch (_) {}
    try { this._selection.refreshSelectionUI(); } catch (_) {}
    try { this._scheduleProbeVisibleCards(); } catch (_) {}
  }

  createPreviewManager() {
    const app = this.app;
    let content = this.contentService;
    if (!content) {
      if (app && app._contentService) {
        content = app._contentService;
        try {
          const authProvider = (app && typeof app._getAuthService === 'function') ? () => app._getAuthService() : undefined;
          content?.setAuthContext?.({ app, authService: authProvider });
        } catch (_) {}
      } else {
        const authProvider = (app && typeof app._getAuthService === 'function') ? () => app._getAuthService() : undefined;
        content = new NexusContentService({ app: app || null, authService: authProvider });
      }
      if (this._controller) this._controller._content = content;
      this._content = content;
    }
    const events = app?._events || null;
    return new AssetPreviewManager(content, events);
  }

  getHoverPreviewDelay() {
    return 100;
  }

  _setIndexingLock(active, message = 'Indexing cloud assets...') {
    this._controller.setIndexingLock(active, message);
  }

  _cancelInFlight(reason = 'cancelled') {
    this._controller.cancelActiveOperations(reason);
  }

  cancelActiveOperations(reason = 'cancelled') {
    this._controller.cancelActiveOperations(reason);
  }

  _markNeedsReload(reason = 'settings') {
    this._controller.markNeedsReload(reason);
  }

  /** Activate the tab: grid, placement manager, footer, hover preview, and data load */
  async onActivate() {
    Logger.info('AssetsTab.onActivate:start', { tab: this.id, hasItems: !!(this._items && this._items.length) });
    const app = this.app;
    this._didDeactivate = false;

    await this._controller.ensureServices();

    if (!app || app._activeTab !== this.id || this._didDeactivate) {
      Logger.info('AssetsTab.onActivate:aborted', { tab: this.id, stage: 'services', activeTab: app?._activeTab });
      return;
    }

    await super.onActivate();
    if (!app || app._activeTab !== this.id || this._didDeactivate) {
      Logger.info('AssetsTab.onActivate:aborted', { tab: this.id, stage: 'grid', activeTab: app?._activeTab });
      return;
    }
    try { this._installProbeScrollHandler(); } catch (_) {}

    // Hook settings updates (while Assets tab is active)
    if (!this._boundSettingsChange) {
      const appRef = this.app;
      this._boundSettingsChange = async (setting) => {
        if (!setting || setting.namespace !== 'fa-nexus') return;
        const isActive = appRef?._activeTab === this.id;
        if (setting.key === 'assetFolders' || setting.key === 'cloudAssetsEnabled') {
          if (!isActive) return;
          if (!app.rendered || !app.element || !app._grid) return;
          this._needsReload = false;
          try {
            await this.loadAssets({ forceReload: true });
          } catch (error) {
            Logger.warn('AssetsTab.settingsReload.failed', {
              tab: this.id,
              setting: setting.key,
              error: String(error?.message || error)
            });
          } finally {
            this._needsReload = this._controller.sharedCatalog.dirty;
          }
          return;
        }
        if (!isActive) return;
        if (!app.rendered || !app.element || !app._grid) return;
        if (setting.key === 'hideLocked') {
          await this.applySearchAsync(this.getCurrentSearchValue());
        } else if (setting.key === 'patreon_auth_data') {
          this._updateHideLockedVisibility();
          try {
            const auth = setting.value;
            if (auth && auth.authenticated && auth.state) {
              game.settings.set('fa-nexus', 'hideLocked', false);
            }
          } catch (_) {}
          await this.applySearchAsync(this.getCurrentSearchValue());
        } else if (setting.key === 'assetDropShadow') {
          this._updateDropShadowControl();
        }
      };
      try { Hooks.on('updateSetting', this._boundSettingsChange); } catch (_) {}
    }

    // Initial data: unified local/cloud pipeline
    const sharedCatalog = this._controller.sharedCatalog;
    const hasOnlySolidTexture = this.isTexturesMode
      && Array.isArray(this._items)
      && this._items.length === 1
      && this._items[0]?.id === '__fa-nexus-solid-color';
    const needsInitialLoad = !Array.isArray(this._items) || this._items.length === 0 || hasOnlySolidTexture;
    const shouldForceReload = this._needsReload || sharedCatalog.dirty;
    if (needsInitialLoad || shouldForceReload) {
      const reason = needsInitialLoad ? 'initial' : 'forced';
      Logger.info('AssetsTab.onActivate:loadAssets:start', { tab: this.id, reason });
      this._needsReload = false;
      const options = shouldForceReload ? { forceReload: true } : {};
      const loadTask = this.loadAssets(options);
      this._activationLoadTask = loadTask;
      loadTask.then(() => {
        Logger.info('AssetsTab.onActivate:loadAssets:complete', { tab: this.id, itemCount: this._items?.length || 0, reason });
      }).catch((error) => {
        Logger.warn('AssetsTab.onActivate:loadAssets:failed', {
          tab: this.id,
          reason,
          error: String(error?.message || error)
        });
      }).finally(() => {
        if (this._activationLoadTask === loadTask) this._activationLoadTask = null;
        if (shouldForceReload) this._needsReload = sharedCatalog.dirty;
      });
    } else {
      Logger.info('AssetsTab.onActivate:useCachedData', { tab: this.id, itemCount: this._items.length });
      // Defer all heavy operations to avoid blocking tab switch completion
      Logger.info('AssetsTab.onActivate:deferOperations', { tab: this.id });
      if (this._deferredActivationTimeout) {
        try { clearTimeout(this._deferredActivationTimeout); } catch (_) {}
      }
      this._deferredActivationTimeout = setTimeout(() => {
        this._deferredActivationTimeout = null;
        if (!this.app || this.app._activeTab !== this.id || !this.app._grid) {
          Logger.info('AssetsTab.onActivate:deferredOps:skipped', { tab: this.id, activeTab: this.app?._activeTab });
          return;
        }
        Logger.info('AssetsTab.onActivate:deferredOps:start', { tab: this.id });
        try {
          if (this.supportsFolderBrowser()) {
            Logger.info('AssetsTab.onActivate:computeFolderStats', { tab: this.id });
            this._computeFolderStats(Array.isArray(this._items) ? this._items : []);
            if (sharedCatalog.items === this._items) {
              sharedCatalog.folderStats.set(this._mode, this._folderStats);
            }
          }
          Logger.info('AssetsTab.onActivate:updateFolderFilter', { tab: this.id });
          this._updateFolderFilter();
          this.app?.updateFolderFilterSelection?.(this.id, this._activeFolderSelection);
        } catch (error) {
          Logger.warn('AssetsTab.onActivate:deferredOps:folderFailed', { tab: this.id, error });
        }

        Logger.info('AssetsTab.onActivate:deferredSearch:start', { tab: this.id });
        this.applySearchAsync(this.getCurrentSearchValue()).then(() => {
          Logger.info('AssetsTab.onActivate:deferredSearch:complete', { tab: this.id });
        }).catch((error) => {
          Logger.warn('AssetsTab.onActivate:deferredSearch:failed', { tab: this.id, error });
        });
        Logger.info('AssetsTab.onActivate:deferredOps:complete', { tab: this.id });
      }, 0);
    }

    // Listen for ESC-based placement cancel to clear selection
    if (!this.isTexturesMode) {
      try {
        if (!this._placementCancelHandler) {
          this._placementCancelHandler = () => {
            try { this._selection.clearSelection(); } catch (_) {}
            try { this._refreshSelectionUIInView(); } catch (_) {}
            Logger.info('AssetsTab.selection.cleared', { reason: 'placement-cancel' });
            this._updateDropShadowControl();
          };
        }
        this.app?.element?.addEventListener?.('fa-nexus:placement-cancelled', this._placementCancelHandler);
      } catch (_) {}
    }

    try {
      if (!this._dropShadowUpdateHandler) {
        this._dropShadowUpdateHandler = () => { this._updateDropShadowControl(); };
      }
      this.app?.element?.addEventListener?.('fa-nexus:drop-shadow-updated', this._dropShadowUpdateHandler);
    } catch (_) {}

    if (this.supportsFolderBrowser()) {
      try { this._updateFolderFilter(); } catch (_) {}
      try { this.app?.updateFolderFilterSelection?.(this.id, this._activeFolderSelection); } catch (_) {}
    }
    this._updateDropShadowControl();
    try {
      queueMicrotask(() => {
        if (!this.app || this.app._activeTab !== this.id) return;
        this._refreshSelectionUIInView();
      });
    } catch (_) {}
  }

  /**
   * Closing the window leaves the tab, and leaving the tab saves an open Texture or Path
   * session that has changes. The save needs the window that hosts the session: it is
   * done and awaited here, before the window goes. A failed save rejects, and the
   * window stays open.
   */
  async saveSessionBeforeApplicationClose() {
    const manager = this.isTexturesMode ? this.texturePaintManager : (this.isPathsMode ? this.pathManagerV2 : null);
    if (!manager?.isActive) return;
    const hasChanges = typeof manager.hasSessionChanges === 'function' ? manager.hasSessionChanges() : true;
    if (!hasChanges) {
      manager.stop?.({ reason: 'app-close' });
      return;
    }
    if (this.isTexturesMode) await manager.save();
    else await (manager.savePath?.() ?? manager.save?.());
  }

  /** Cleanup listeners and transient UI when leaving the tab */
  onDeactivate() {
    if (this._didDeactivate) return;
    this._didDeactivate = true;
    const reportSaveFailure = (mode, editor, error) => {
      const message = String(error?.message || error || 'Unknown save error');
      Logger.error('AssetsTab.deactivateSave.failed', {
        tab: this.id,
        mode,
        editor,
        reason: 'tab-deactivate',
        error: message
      });
      try {
        globalThis.ui?.notifications?.error?.(`Unable to save ${editor} changes: ${message}`);
      } catch (notificationError) {
        Logger.warn('AssetsTab.deactivateSave.notificationFailed', {
          tab: this.id,
          mode,
          editor,
          reason: 'tab-deactivate',
          error: String(notificationError?.message || notificationError)
        });
      }
    };
    if (this._deferredActivationTimeout) {
      try { clearTimeout(this._deferredActivationTimeout); } catch (_) {}
      this._deferredActivationTimeout = null;
    }
    this._cancelInFlight('deactivate');
    if (this.isTexturesMode) {
      try {
        if (this.texturePaintManager?.isActive) {
          const hasChanges = typeof this.texturePaintManager?.hasSessionChanges === 'function'
            ? this.texturePaintManager.hasSessionChanges()
            : true;
          if (hasChanges) {
            const result = this.texturePaintManager?.save?.();
            if (result?.catch) {
              result.catch((error) => {
                reportSaveFailure('textures', 'texture editor', error);
              });
            }
          } else {
            this.texturePaintManager?.stop?.({ reason: 'tab-deactivate' });
          }
        }
      } catch (error) {
        reportSaveFailure('textures', 'texture editor', error);
      }
    } else if (this.isPathsMode) {
      try {
        if (this.pathManagerV2?.isActive) {
          const hasChanges = typeof this.pathManagerV2?.hasSessionChanges === 'function'
            ? this.pathManagerV2.hasSessionChanges()
            : true;
          if (hasChanges) {
            const result = this.pathManagerV2?.savePath?.() ?? this.pathManagerV2?.save?.();
            if (result?.catch) {
              result.catch((error) => {
                reportSaveFailure('paths', 'path editor', error);
              });
            }
          } else {
            this.pathManagerV2?.stop?.({ reason: 'tab-deactivate' });
          }
        }
      } catch (error) {
        reportSaveFailure('paths', 'path editor', error);
      }
    } else {
      // Cancel any active placement when leaving assets tab
      try { this.placementManager?.cancelPlacement?.('tab-switch'); } catch (_) {}
      try {
        if (this._placementCancelHandler) {
          this.app?.element?.removeEventListener?.('fa-nexus:placement-cancelled', this._placementCancelHandler);
        }
      } catch (_) {}
      try {
        this._selection?.clearSelection?.();
        this._refreshSelectionUIInView?.();
      } catch (_) {}
    }
    try {
      if (this._dropShadowUpdateHandler) {
        this.app?.element?.removeEventListener?.('fa-nexus:drop-shadow-updated', this._dropShadowUpdateHandler);
      }
    } catch (_) {}
    try {
      if (this._boundSettingsChange) {
        Hooks.off('updateSetting', this._boundSettingsChange);
        this._boundSettingsChange = null;
      }
    } catch (_) {}
    try { this._uninstallProbeScrollHandler(); } catch (_) {}
    super.onDeactivate();
  }

  filterItems(items, query) {
    let filtered = super.filterItems(items, query);
    if (!Array.isArray(filtered)) filtered = [];

    try {
      const hideLocked = game.settings.get('fa-nexus', 'hideLocked');
      if (hideLocked) {
        let authed = false;
        try {
          const auth = game.settings.get('fa-nexus', 'patreon_auth_data');
          authed = !!(auth && auth.authenticated && auth.state);
        } catch (_) {}

        const download = this.downloadManager;
        filtered = filtered.filter((asset) => {
          if (!asset) return false;
          const source = String(asset.source || '').toLowerCase();
          const isPremium = String(asset.tier || '').toLowerCase() === 'premium';
          if (source !== 'cloud' || !isPremium) return true;
          if (authed) return true;

          // Treat downloaded assets as unlocked even if user lacks premium auth.
          if (asset.cachedLocalPath || asset.cached || asset.isCached) return true;
          try {
            const localPath = download?.getLocalPath?.('assets', asset);
            if (localPath) {
              asset.cachedLocalPath = asset.cachedLocalPath || localPath;
              return true;
            }
          } catch (_) {}
          return false;
        });
      }
    } catch (_) {}

    filtered = filtered.filter((asset) => this._matchesMode(asset));

    if (this.supportsFolderBrowser() && !this.app._collections?.active) {
      const matchesFolder = createFolderSelectionPredicate(this._activeFolderSelection);
      filtered = filtered.filter((asset) => matchesFolder(this._getNormalizedFolderPath(asset)));
    }

    return filtered;
  }

  _isCloudEnabled() {
    return this._controller.isCloudEnabled();
  }

  describeEmptyState() {
    if (!this._isCloudEnabled() && !getEnabledFolders('assetFolders').length) {
      return 'No asset source is enabled. Enable FA Cloud Assets or a local folder in Configure Settings, FA Nexus, Asset Sources.';
    }
    return super.describeEmptyState();
  }

  destroy() {
    try { this.onDeactivate(); }
    catch (error) {
      Logger.warn('AssetsTab.destroy.deactivateFailed', { tab: this.id, error: String(error?.message || error) });
    }
    try { this.placementManager?.destroy?.(); }
    catch (error) {
      Logger.warn('AssetsTab.destroy.placementDestroyFailed', { tab: this.id, error: String(error?.message || error) });
    }
    try { this._probe?.dispose?.(); } catch (_) {}
    try { this._controller?.dispose?.(); } catch (_) {}
    this._placement = null;
    if (super.destroy) super.destroy();
  }

  /** Bind footer controls (hide main-color toggle; add assets folder button) */
  bindFooter() {
    try {
      const appEl = this.app.element;
      if (!appEl) return;
      const cb = appEl.querySelector('#fa-nexus-maincolor-only');
      const wrap = cb?.closest?.('.fa-nexus-footer-control') || cb?.parentElement;
      if (wrap) wrap.style.display = 'none';
      // Remove token-specific folder button if present
      const tokenBtn = appEl.querySelector('.fa-nexus-footer .actions .fa-nexus-open-folder');
      if (tokenBtn) tokenBtn.remove();
      const hideLockCb = appEl.querySelector('#fa-nexus-hide-locked');
      if (hideLockCb) {
        let authed = false;
        try {
          const auth = game.settings.get('fa-nexus', 'patreon_auth_data');
          authed = !!(auth && auth.authenticated && auth.state);
        } catch (_) {}
        const hideWrap = hideLockCb.closest?.('.fa-nexus-footer-control') || hideLockCb.parentElement;
        if (hideWrap) hideWrap.style.display = authed ? 'none' : '';
        if (!authed) {
          hideLockCb.checked = !!game.settings.get('fa-nexus', 'hideLocked');
          hideLockCb.addEventListener('change', async () => {
            try {
              await game.settings.set('fa-nexus', 'hideLocked', !!hideLockCb.checked);
              await this.applySearchAsync(this.getCurrentSearchValue());
            } catch (_) {}
          });
        }
      }
      // Add assets folder button
      const actions = appEl.querySelector('.fa-nexus-footer .actions');
      if (actions && !actions.querySelector('.fa-nexus-open-asset-folder')) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'fa-nexus-icon-button fa-nexus-open-asset-folder';
        btn.title = 'Select Asset Sources';
        btn.innerHTML = '<i class="fas fa-folder-open"></i>';
        btn.addEventListener('click', (ev) => {
          ev.preventDefault();
          try {
            const { FaNexusAssetsFolderSelectionDialog } = window.faNexus || {};
            if (FaNexusAssetsFolderSelectionDialog) { new FaNexusAssetsFolderSelectionDialog().render(true); return; }
          } catch (_) {}
          import('./assets-content-sources-dialog.js').then((m) => {
            new m.FaNexusAssetsFolderSelectionDialog().render(true);
          }).catch(() => {});
        });
        actions.appendChild(btn);
      }
      this._updateHideLockedVisibility();
      this._updateDropShadowControl();
    } catch (_) {}
  }

  /** Unbind footer controls and remove transient buttons */
  unbindFooter() {
    try {
      const appEl = this.app.element;
      const cb = appEl?.querySelector('#fa-nexus-maincolor-only');
      if (cb) {
        const clone = cb.cloneNode(true);
        cb.parentNode.replaceChild(clone, cb);
      }
      const hideLockCb = appEl?.querySelector('#fa-nexus-hide-locked');
      if (hideLockCb) {
        const clone = hideLockCb.cloneNode(true);
        hideLockCb.parentNode.replaceChild(clone, hideLockCb);
      }
      const assetBtn = appEl?.querySelector('.fa-nexus-footer .actions .fa-nexus-open-asset-folder');
      if (assetBtn) assetBtn.remove();
    } catch (_) {}
  }

  _updateHideLockedVisibility() {
    try {
      const appEl = this.app?.element;
      if (!appEl) return;
      const hideLockCb = appEl.querySelector('#fa-nexus-hide-locked');
      if (!hideLockCb) return;
      let authed = false;
      try {
        const auth = game.settings.get('fa-nexus', 'patreon_auth_data');
        authed = !!(auth && auth.authenticated && auth.state);
      } catch (_) {}
      const wrap = hideLockCb.closest?.('.fa-nexus-footer-control') || hideLockCb.parentElement;
      if (wrap) wrap.style.display = authed ? 'none' : '';
      if (!authed) {
        hideLockCb.checked = !!game.settings.get('fa-nexus', 'hideLocked');
      }
    } catch (_) {}
  }

  _updateDropShadowControl() {
    try {
      this.placementManager?.refreshToolOptions?.();
    } catch (_) {}
  }

  onThumbSizeChange() { /* handled via slider binding */ }

  /** Return stats for footer display */
  getStats() {
    const app = this.app;
    // Filter items to only count those relevant to the current tab mode
    const allItems = this._items || [];
    const relevantItems = allItems.filter(item => this._matchesMode(item));
    const total = relevantItems.length;
    const shown = (app._grid && Array.isArray(app._grid.items)) ? app._grid.items.length : 0;
    return { shown, total };
  }

  /** Load cached assets, stream remaining folders, and update grid */
  async loadAssets(options = {}) {
    return this._controller.loadAssets(options);
  }

  async _loadAssetsInternal(options = {}) {
    return this._controller.loadAssetsInternal(options);
  }

  async _loadAndMergeCloud(includeLocal, options = {}) {
    return this._controller.loadAndMergeCloud(includeLocal, options);
  }

  /** Load cloud assets list safely (logs and returns [] on failure) */
  async _loadCloudAssetsSafe(onProgress, signal) {
    return this._controller.loadCloudAssetsSafe(onProgress, signal);
  }

  _createAssetCard(it) {
    return this._cards.createCard(it);
  }

  _mountAssetCard(cardElement, it) {
    return this._cards.mountCard(cardElement, it);
  }

  _unmountAssetCard(cardElement) {
    this._cards.unmountCard(cardElement);
  }

  _handleAssetCardClick(ev, cardElement, it) {
    return this._cards.handleAssetCardClick(ev, cardElement, it);
  }

  async _beginAssetPlacement(cardElement, it, isStickyMode = true, pointerEvent = null) {
    const folderPath = cardElement.getAttribute('data-folder') || this._resolveFolderPath(it) || '';
    const filePathAttr = cardElement.getAttribute('data-content-path') || this._resolveFilePath(it);
    const filename = contentFilename(it);
    const isCloud = (cardElement.getAttribute('data-source') === 'cloud');
    const tier = cardElement.getAttribute('data-tier') || '';
    const dataUrlAttr = cardElement.getAttribute('data-url') || '';
    let cachedLocalPath = '';
    let dimensionsReady = false;

    try { await this._controller.ensureServices(); }
    catch (error) {
      this._reportAssetPlacementFailure('AssetsTab.place.ensure.failed', error);
      throw error;
    }
    const download = this.downloadManager;

    if (isCloud) {
      try {
        if (cardElement.getAttribute('data-cached') === 'true') {
          cachedLocalPath = cardElement.getAttribute('data-url') || '';
        }
      } catch (_) {}
      if (!cachedLocalPath && it?.cachedLocalPath) cachedLocalPath = it.cachedLocalPath;
      if (!cachedLocalPath) {
        try {
          cachedLocalPath = download?.getLocalPath?.('assets', it) || '';
        } catch (_) { cachedLocalPath = ''; }
      }
      if (cachedLocalPath) {
        try { cardElement.setAttribute('data-url', cachedLocalPath); } catch (_) {}
        try { cardElement.setAttribute('data-cached', 'true'); } catch (_) {}
        it.cachedLocalPath = cachedLocalPath;
        const icon = cardElement.querySelector('.fa-nexus-status-icon');
        if (icon) {
          icon.classList.remove('cloud-plus', 'cloud', 'premium');
          icon.classList.add('cloud', 'cached');
          icon.title = 'Downloaded';
          icon.innerHTML = '<i class="fas fa-cloud-check"></i>';
        }
        dimensionsReady = await this._cards.ensureAccurateDimensions(it, cardElement);
      }
    } else {
      cachedLocalPath = dataUrlAttr || filePathAttr || folderPath;
      if (cachedLocalPath) {
        try { cardElement.setAttribute('data-url', cachedLocalPath); } catch (_) {}
      }
      dimensionsReady = await this._cards.ensureAccurateDimensions(it, cardElement);
    }

    if (!dimensionsReady && cachedLocalPath) {
      try { dimensionsReady = await this._cards.ensureAccurateDimensions(it, cardElement); } catch (_) {}
    }

    const [gridWidthVal, gridHeightVal] = contentGrid(it);
    const widthPx = Math.round(gridWidthVal * 200);
    const heightPx = Math.round(gridHeightVal * 200);

    const assetData = {
      ...it,
      source: isCloud ? 'cloud' : (it?.source || 'local'),
      tier: tier || it?.tier || 'free',
      cachedLocalPath,
      file_path: filePathAttr,
      filename,
      folder_path: folderPath,
      path: cachedLocalPath || filePathAttr || folderPath,
      url: cachedLocalPath || '',
      grid: [gridWidthVal, gridHeightVal],
      grid_width: gridWidthVal,
      grid_height: gridHeightVal,
      width: widthPx,
      height: heightPx,
      actual_width: it?.actual_width || widthPx,
      actual_height: it?.actual_height || heightPx
    };
    const placement = this.placementManager;
    if (placement?.updatePlacementAssets) {
      try {
        const updated = await placement.updatePlacementAssets(assetData, { pointerEvent });
        if (updated) return;
      } catch (error) {
        this._reportAssetPlacementFailure('AssetsTab.place.update.failed', error, { filename });
        throw error;
      }
    }
    if (typeof placement?.startPlacement !== 'function') {
      const error = new Error('Asset placement manager is unavailable.');
      this._reportAssetPlacementFailure('AssetsTab.place.start.missingManager', error, { filename });
      throw error;
    }
    try {
      placement.startPlacement(assetData, isStickyMode, { pointerEvent });
    } catch (error) {
      this._reportAssetPlacementFailure('AssetsTab.place.start.failed', error, { filename });
      throw error;
    }
  }

  async _handleTextureCardClick(cardElement, item) {
    return this._cards.handleTextureCardClick(cardElement, item);
  }

  async _handlePathCardClick(cardElement, item) {
    return this._cards.handlePathCardClick(cardElement, item);
  }

  // ======== Multi-select helpers ========
  _computeItemKey(item) {
    return this._selection.computeItemKey(item);
  }

  _keyFromCard(cardElement) {
    return this._selection.keyFromCard(cardElement);
  }

  _indexOfVisibleKey(key, fallbackItem = null) {
    return this._selection.indexOfVisibleKey(key, fallbackItem);
  }

  _applyRangeSelection(from, to, mode = 'add') {
    this._selection.applyRangeSelection(from, to, mode);
  }

  _applyRangeSelectionExclusive(from, to) {
    this._selection.applyRangeSelectionExclusive(from, to);
  }

  _setCardSelectionUI(card, selected) {
    this._selection.setCardSelectionUI(card, selected);
  }

  _refreshSelectionUIInView() {
    this._selection.refreshSelectionUI();
  }

  async _startPlacementFromSelection() {
    if (this.isTexturesMode) return;
    try { await this._selection.startPlacementFromSelection(); }
    catch (error) {
      this._reportAssetPlacementFailure('AssetsTab.place.selection.failed', error);
      throw error;
    }
  }

  _updateCardGridBadge(cardElement, item = null) {
    this._cards.updateCardGridBadge(cardElement, item);
  }

  _resolveFilePath(item) {
    if (!item) return '';
    return contentPath(item);
  }

  _isSolidTextureItem(item) {
    return !!(item && (item.isSolidTexture || item.id === SOLID_TEXTURE_ITEM_ID));
  }

  _getGridSortPinRank(item, context = {}) {
    if (this.isTexturesMode && this._isSolidTextureItem(item)) return -1;
    return super._getGridSortPinRank?.(item, context) || 0;
  }

  _getSolidTextureColor() {
    try {
      const stored = game?.settings?.get?.('fa-nexus', 'solidTextureColor');
      return normalizeSolidTextureColor(stored);
    } catch (_) {
      return SOLID_TEXTURE_DEFAULT_COLOR;
    }
  }

  _getSolidTexturePlaceholderPath() {
    try {
      const raw = game?.modules?.get?.('fa-nexus')?.url ?? 'modules/fa-nexus';
      const routed = globalThis?.foundry?.utils?.getRoute?.(raw) ?? raw;
      return `${normalizeFaNexusModulePath(routed)}/images/transparent.png`;
    } catch (_) {
      return 'modules/fa-nexus/images/transparent.png';
    }
  }

  _notifyActiveSolidTextureSessionColor(color, { commit = false } = {}) {
    const manager = this.texturePaintManager;
    if (!manager?.isActive) return false;
    if (typeof manager.setSolidTextureColor !== 'function') {
      Logger.error('AssetsTab.solidTextureColor.activeSessionUnsupported', {
        color,
        manager: manager?.constructor?.name || null
      });
      return false;
    }
    try {
      const result = manager.setSolidTextureColor(color, { commit });
      if (result?.catch) {
        result.catch((error) => {
          Logger.error('AssetsTab.solidTextureColor.activeSessionSyncFailed', {
            color,
            error: String(error?.message || error)
          });
        });
      }
      return result !== false;
    } catch (error) {
      Logger.error('AssetsTab.solidTextureColor.activeSessionSyncFailed', {
        color,
        error: String(error?.message || error)
      });
      return false;
    }
  }

  _previewSolidTextureColor(value) {
    const normalized = normalizeSolidTextureColor(value);
    this._notifyActiveSolidTextureSessionColor(normalized, { commit: false });
    return normalized;
  }

  _setSolidTextureColor(value, { persist = true, notifyTexturePaint = true } = {}) {
    const normalized = normalizeSolidTextureColor(value);
    if (this._solidTextureItem && this._solidTextureItem.solidColor !== normalized) {
      this._applySolidTextureColor(this._solidTextureItem, normalized);
    }
    if (notifyTexturePaint) {
      this._notifyActiveSolidTextureSessionColor(normalized, { commit: !!persist });
    }
    if (persist) {
      try {
        const result = game?.settings?.set?.('fa-nexus', 'solidTextureColor', normalized);
        if (result?.catch) {
          result.catch((error) => {
            Logger.error('AssetsTab.solidTextureColor.persistFailed', {
              color: normalized,
              error: String(error?.message || error)
            });
          });
        }
      } catch (error) {
        Logger.error('AssetsTab.solidTextureColor.persistFailed', {
          color: normalized,
          error: String(error?.message || error)
        });
      }
    }
    return normalized;
  }

  _applySolidTextureColor(item, color) {
    if (!item) return null;
    const normalized = normalizeSolidTextureColor(color);
    const dataUrl = buildSolidTextureDataUrl(normalized);
    item.solidColor = normalized;
    item.cachedLocalPath = dataUrl;
    item.thumbnail_url = dataUrl;
    item.url = dataUrl;
    item.grid = [1, 1];
    return item;
  }

  _getSolidTextureItem() {
    const color = this._getSolidTextureColor();
    if (!this._solidTextureItem) {
      const item = {
        id: SOLID_TEXTURE_ITEM_ID,
        folder: '',
        name: 'Solid Color',
        source: 'local',
        tier: 'free',
        kind: 'asset',
        asset_class: 'texture',
        selected_source: { format: 'webp', ext: '.webp', size: 0, mtime: new Date().toISOString() },
        isSolidTexture: true,
        tags: ['solid', 'color', 'paint']
      };
      this._solidTextureItem = this._applySolidTextureColor(item, color);
    } else if (this._solidTextureItem.solidColor !== color) {
      this._applySolidTextureColor(this._solidTextureItem, color);
    }
    return this._solidTextureItem;
  }

  _injectSolidTextureItem(items) {
    if (!this.isTexturesMode) return items;
    const list = Array.isArray(items) ? items : [];
    const solidItem = this._getSolidTextureItem();
    if (!solidItem) return list;
    const index = list.findIndex((it) => this._isSolidTextureItem(it));
    if (index === -1) {
      list.unshift(solidItem);
    } else if (index > 0) {
      list.splice(index, 1);
      list.unshift(solidItem);
    } else if (list[0] !== solidItem) {
      list[0] = solidItem;
    }
    return list;
  }

  _resolveFolderPath(item) {
    return contentFolder(item) || this._controller.resolveFolderPath(item);
  }

  _hasPremiumAuth() {
    try {
      const auth = game.settings.get('fa-nexus', 'patreon_auth_data');
      return !!(auth && auth.authenticated && auth.state);
    } catch (_) {
      return false;
    }
  }

  /** Whether the stored Patreon login's tier includes premium assets (see patreon-auth-contract.js). */
  _hasPremiumContentAccess() {
    try {
      return hasContentProductAccess(game.settings.get('fa-nexus', 'patreon_auth_data'), 'assets');
    } catch (_) {
      return false;
    }
  }

  /** The message for a click on a locked premium asset card. */
  _lockedPremiumAssetMessage() {
    let authData = null;
    try { authData = game.settings.get('fa-nexus', 'patreon_auth_data'); } catch (_) {}
    return lockedPremiumContentMessage(authData, 'premium assets');
  }

  _isAssetLocked(item, cardElement = null, { authed } = {}) {
    try {
      const el = cardElement || null;
      const hasAuth = typeof authed === 'boolean' ? authed : this._hasPremiumAuth();

      const cachedAttr = el?.getAttribute?.('data-cached') === 'true';
      if (cachedAttr) {
        try { el.removeAttribute('data-locked'); } catch (_) {}
        return false;
      }

      const itemCached = !!(item && (item.cachedLocalPath || item.cached || item.isCached));
      if (itemCached) {
        if (el) {
          try { el.removeAttribute('data-locked'); } catch (_) {}
        }
        return false;
      }

      const source = (el?.getAttribute?.('data-source') || item?.source || '').toLowerCase();
      if (source !== 'cloud') {
        if (el) {
          try { el.removeAttribute('data-locked'); } catch (_) {}
        }
        return false;
      }

      const tier = (el?.getAttribute?.('data-tier') || item?.tier || '').toLowerCase();
      if (tier !== 'premium') {
        if (el) {
          try { el.removeAttribute('data-locked'); } catch (_) {}
        }
        return false;
      }

      if (hasAuth && this._hasPremiumContentAccess()) {
        if (el) {
          try { el.removeAttribute('data-locked'); } catch (_) {}
        }
        return false;
      }

      const download = this.downloadManager;
      if (download && item) {
        try {
          const localPath = download.getLocalPath?.('assets', item);
          if (localPath) {
            if (item && !item.cachedLocalPath) item.cachedLocalPath = localPath;
            if (el) {
              try { el.removeAttribute('data-locked'); } catch (_) {}
            }
            return false;
          }
        } catch (_) {}
      }

      if (el) {
        try { el.setAttribute('data-locked', 'true'); } catch (_) {}
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  _normalizeFolderPath(path) {
    return this._controller.normalizeFolderPath(path);
  }

  _getFolderPathInfo(item, hydrate = false) {
    return this._controller.getFolderPathInfo(item, hydrate);
  }

  _computeFolderStats(items) {
    return this._controller.computeFolderStats(items);
  }

  _getNormalizedFolderPath(item) {
    return this._controller.getNormalizedFolderPath(item);
  }


  _updateFolderFilter() {
    return this._controller.updateFolderFilter();
  }

  _isTextureItem(item) {
    if (!item) return false;
    if (this._isSolidTextureItem(item)) return true;
    if (item.asset_class) return String(item.asset_class).toLowerCase() === 'texture';
    const filePath = String(this._resolveFilePath(item) || '').toLowerCase();
    const folderPath = String(this._resolveFolderPath(item) || '').toLowerCase();
    if (/\/textures\//.test(filePath)) return true;
    if (/\/textures\//.test(folderPath)) return true;
    if (/\/texture[_-]?overlays\//.test(filePath)) return true;
    if (/\/texture[_-]?overlays\//.test(folderPath)) return true;
    return false;
  }

  _looksLikePathsSegment(value) {
    if (!value) return false;
    const normalized = String(value).toLowerCase().replace(/\\/g, '/');
    return /(^|[\/\-_])paths?(?=[\/\-_]|$)/.test(normalized);
  }

  _isPathsItem(item) {
    if (!item) return false;
    if (item.asset_class) return String(item.asset_class).toLowerCase() === 'path';
    const filename = contentFilename(item).toLowerCase();
    if (filename.includes('path')) return true;
    const filePath = this._resolveFilePath(item);
    const folderPath = this._resolveFolderPath(item);
    if (this._looksLikePathsSegment(folderPath)) return true;
    if (this._looksLikePathsSegment(filePath)) return true;
    return false;
  }

  _matchesMode(item) {
    try { return this._controller?.matchesMode(item); }
    catch (_) { return false; }
  }

  _needsActualDimensions(item) {
    return this._cards.needsActualDimensions(item);
  }

  _hasLocalAssetFile(item) {
    return this._cards.hasLocalAssetFile(item);
  }

  async _ensureAccurateDimensions(item, cardElement) {
    return this._cards.ensureAccurateDimensions(item, cardElement);
  }

  // ======== Throttled image loading (assets grid) ========
  // ======== Deferred cache probing (after scroll settles) ========
  _installProbeScrollHandler() {
    const grid = this.getGridContainer();
    if (!grid) return;
    const onScroll = () => { this._scheduleProbeVisibleCards(); };
    grid.addEventListener('scroll', onScroll, { passive: true });
    this._probeScrollHandler = onScroll;
  }

  _uninstallProbeScrollHandler() {
    const grid = this.getGridContainer();
    if (!grid || !this._probeScrollHandler) return;
    try { grid.removeEventListener('scroll', this._probeScrollHandler); } catch (_) {}
    this._probeScrollHandler = null;
    this._probe.dispose();
  }

  _scheduleProbeVisibleCards() {
    this._probe.scheduleVisibleCards();
  }

  _runProbeVisibleCards() {
    const grid = this.getGridContainer(); if (!grid) return;
    const cards = grid.querySelectorAll('.fa-nexus-card[data-source="cloud"]:not([data-cached="true"])');
    const loader = this._probe.ensureLoader();
    loader.queue.clear();
    for (const c of cards) loader.queue.add(c);
    this._probe.runQueue();
  }

  _enqueueCacheProbe(cardElement, item) {
    this._probe.queueCard(cardElement, item);
  }
  _updateFooterStats() {
    try {
      const stats = this.app.element.querySelector('.fa-nexus-footer .stats');
      if (!stats) return;
      const { shown, total } = this.getStats();
      stats.textContent = `${shown} / ${total}`;
    } catch (_) {}
  }

  _bindThumbSizeSlider() {
    const app = this.app;
    const gridContainer = app.element.querySelector('#fa-nexus-grid');
    let sizeInput = app.element.querySelector('#fa-nexus-thumb-size');
    if (!sizeInput || !app._grid) return;
    // Replace node to drop previous listeners (from other tab)
    try { const parent = sizeInput.parentNode; const clone = sizeInput.cloneNode(true); parent.replaceChild(clone, sizeInput); sizeInput = clone; } catch (_) {}

    const settingKey = this._getThumbSettingKey();
    const min = this.thumbSliderMin;
    const max = this.thumbSliderMax;
    const step = this.thumbSliderStep || 2;
    const sanitize = (value) => this._sanitizeThumbSize(value);

    sizeInput.min = String(min);
    sizeInput.max = String(max);
    sizeInput.step = String(step);

    const saved = this._getStoredThumbSize();
    sizeInput.value = String(sanitize(saved));

    let pendingValue = sanitize(sizeInput.value);
    let rafId = null;

    const applyDims = (w) => {
      const clamped = sanitize(w);
      const dims = this._computeThumbDimensions(clamped);
      const t = Math.max(0, Math.min(1, (clamped - min) / (max - min)));
      try { app._grid.setCardSize(dims.width, dims.height); } catch (_) {}
      applyGridDensityStyles(gridContainer, t);
      try { this.app?.updateGridPlaceholderSize?.({ tab: this.id, width: dims.width, height: dims.height, gap: this.getGridOptions?.()?.card?.gap ?? 4 }); } catch (_) {}
      try { this._updateFooterStats(); } catch (_) {}
    };

    const flushPending = () => {
      rafId = null;
      applyDims(pendingValue);
    };

    const scheduleApply = (w) => {
      pendingValue = sanitize(w);
      if (rafId) return;
      if (typeof requestAnimationFrame === 'function') {
        rafId = requestAnimationFrame(flushPending);
      } else {
        flushPending();
      }
    };

    scheduleApply(sizeInput.value);

    const onInput = () => {
      scheduleApply(sizeInput.value);
    };

    const onChange = async () => {
      const w = sanitize(sizeInput.value);
      scheduleApply(w);
      try { await game.settings.set('fa-nexus', settingKey, w); } catch (_) {}
    };

    let dragging = false;
    const endDrag = () => {
      if (!dragging) return;
      dragging = false;
      scheduleApply(sizeInput.value);
      this._endThumbSizeAdjust?.();
      window.removeEventListener('pointerup', endDrag, true);
      window.removeEventListener('pointercancel', endDrag, true);
    };

    sizeInput.addEventListener('pointerdown', () => {
      if (dragging) return;
      dragging = true;
      this._beginThumbSizeAdjust?.();
      window.addEventListener('pointerup', endDrag, true);
      window.addEventListener('pointercancel', endDrag, true);
    });

    sizeInput.addEventListener('input', onInput);
    sizeInput.addEventListener('change', onChange);
  }

  _beginThumbSizeAdjust() {
    super._beginThumbSizeAdjust();
    this._pendingProbeAfterThumbAdjust = true;
    this._probe.reset();
  }

  _endThumbSizeAdjust() {
    super._endThumbSizeAdjust();
    if (!this.isThumbSizeAdjustActive && this._pendingProbeAfterThumbAdjust) {
      this._pendingProbeAfterThumbAdjust = false;
      this._scheduleProbeVisibleCards();
    }
  }

  /**
   * Dedupe assets by filename (no extension), preferring:
   * 1) source: local > cloud(cached) > cloud
   * 2) extension: webp > png > jpg > others
   * 3) newest last_modified
   */
}
