import {
  appendStoragePath,
  sanitizeGeneratedPathSegment,
  sanitizeStoragePathSegments
} from './path-utils.js';
import { getContentKindDescriptor } from '../content/content-kind-descriptors.js';

const MODULE_ID = 'fa-nexus';
const GENERATED_ROOT_SEGMENT = '__generated';
const MASKS_SEGMENT = 'masks';
const FLATTENED_SEGMENT = 'flattened';

export {
  appendStoragePath,
  sanitizeGeneratedPathSegment,
  sanitizeStoragePathSegments
};

export function getConfiguredAssetsDir({ moduleId = MODULE_ID } = {}) {
  const defaultDir = getContentKindDescriptor('assets').downloadDirDefault;
  try {
    return String(game?.settings?.get?.(moduleId, 'cloudDownloadDirAssets') || defaultDir).trim() || defaultDir;
  } catch (_) {
    return defaultDir;
  }
}

export function getCurrentWorldId() {
  return sanitizeGeneratedPathSegment(game?.world?.id || '', '');
}

export function getSceneId(scene = null) {
  const candidate = scene?.id || canvas?.scene?.id || game?.scenes?.current?.id || '';
  return sanitizeGeneratedPathSegment(candidate, '');
}

export function normalizeGeneratedKind(kind = 'flattened') {
  const value = String(kind || '').trim().toLowerCase();
  if (value === 'mask' || value === MASKS_SEGMENT) return MASKS_SEGMENT;
  if (value === 'flatten' || value === FLATTENED_SEGMENT) return FLATTENED_SEGMENT;
  throw new Error(`Unsupported generated asset kind: ${kind}`);
}

export function buildGeneratedRoot(kind, { assetsDir } = {}) {
  return appendStoragePath(
    appendStoragePath(String(assetsDir || getConfiguredAssetsDir()).trim(), GENERATED_ROOT_SEGMENT),
    normalizeGeneratedKind(kind)
  );
}

export function buildWorldGeneratedFolder(root, { worldId } = {}) {
  const cleanRoot = String(root || '').trim();
  const resolvedWorldId = sanitizeGeneratedPathSegment(worldId || getCurrentWorldId(), '');
  if (!cleanRoot) throw new Error('Generated asset root is required');
  if (!resolvedWorldId) throw new Error('Current world id is unavailable');
  return appendStoragePath(cleanRoot, resolvedWorldId);
}

export function buildSceneGeneratedFolder(root, { worldId, sceneId } = {}) {
  const worldFolder = buildWorldGeneratedFolder(root, { worldId });
  const resolvedSceneId = sanitizeGeneratedPathSegment(sceneId || getSceneId(), '');
  if (!resolvedSceneId) throw new Error('Current scene id is unavailable');
  return appendStoragePath(worldFolder, resolvedSceneId);
}

export function resolveGeneratedSceneFolder(kind, { root, assetsDir, worldId, sceneId } = {}) {
  const generatedRoot = String(root || '').trim() || buildGeneratedRoot(kind, { assetsDir });
  return {
    kind: normalizeGeneratedKind(kind),
    root: generatedRoot,
    worldId: sanitizeGeneratedPathSegment(worldId || getCurrentWorldId(), ''),
    sceneId: sanitizeGeneratedPathSegment(sceneId || getSceneId(), ''),
    folder: buildSceneGeneratedFolder(generatedRoot, { worldId, sceneId })
  };
}

export function resolveGeneratedMaskSlotPath({
  root,
  assetsDir,
  worldId,
  sceneId,
  family = 'mask',
  slotId = '',
  slot = 'a',
  extension = 'webp'
} = {}) {
  const generatedPath = resolveGeneratedSceneFolder('masks', { root, assetsDir, worldId, sceneId });
  const safeFamily = sanitizeGeneratedPathSegment(family, 'mask');
  const safeSlotId = sanitizeGeneratedPathSegment(slotId, 'mask');
  const safeSlot = sanitizeGeneratedPathSegment(slot, 'a').toLowerCase() === 'b' ? 'b' : 'a';
  const safeExtension = sanitizeGeneratedPathSegment(String(extension || 'webp').replace(/^\.+/, ''), 'webp').toLowerCase();
  const filename = `${safeFamily}-${safeSlotId}-${safeSlot}.${safeExtension}`;
  return {
    ...generatedPath,
    family: safeFamily,
    slotId: safeSlotId,
    slot: safeSlot,
    extension: safeExtension,
    filename,
    path: appendStoragePath(generatedPath.folder, filename)
  };
}
