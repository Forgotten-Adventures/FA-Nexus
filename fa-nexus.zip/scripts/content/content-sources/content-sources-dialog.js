const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
import { NexusLogger as Logger } from '../../core/nexus-logger.js';
import {
  browseFolderPickerWithFallbacks,
  getFilePickerClass,
  normalizePickedFolderPath,
  prepareFolderPickerContext
} from '../../storage/file-picker-folder-browser.js';
import { readFaNexusCloudEnabledSetting } from '../../core/cloud-enabled-settings.js';
import { ContentSourcesIndexer } from './content-sources-indexer.js';
import {
  normalizeContentSourcePath,
  contentSourceKey,
  parseContentSourcesSetting,
  serializeContentSourcesSetting
} from './content-sources-service.js';
import { getContentKindDescriptor } from '../content-kind-descriptors.js';

const CONTENT_SOURCES_TEMPLATE = 'modules/fa-nexus/templates/content/content-sources-dialog.hbs';

function createFaIcon(iconClass) {
  const icon = document.createElement('i');
  icon.className = `fas ${iconClass}`;
  icon.setAttribute('aria-hidden', 'true');
  return icon;
}

function setIconOnlyContent(element, iconClass) {
  if (!element) return;
  element.replaceChildren(createFaIcon(iconClass));
}

function setIconTextContent(element, iconClass, text) {
  if (!element) return;
  const label = document.createElement('span');
  label.textContent = String(text ?? '');
  element.replaceChildren(createFaIcon(iconClass), document.createTextNode(' '), label);
}

export function createContentSourcesLocalIndexer({
  dataService,
  streamMethod,
  saveMethod,
  batchSize = 220,
  sleepMs = 8
} = {}) {
  if (!dataService || typeof dataService[streamMethod] !== 'function') {
    throw new TypeError(`Invalid content sources stream method: ${String(streamMethod || '')}`);
  }
  if (typeof dataService[saveMethod] !== 'function') {
    throw new TypeError(`Invalid content sources save method: ${String(saveMethod || '')}`);
  }
  return async (folder, { onProgress, signal } = {}) => {
    if (!folder) return { count: 0 };
    const abortError = () => {
      try { return new DOMException(signal?.reason || 'Cancelled', 'AbortError'); }
      catch (_) {
        const err = new Error(signal?.reason || 'Cancelled');
        err.name = 'AbortError';
        return err;
      }
    };
    const checkAbort = () => { if (signal?.aborted) throw abortError(); };
    const emit = (info) => {
      if (typeof onProgress !== 'function') return;
      try {
        onProgress(info);
      } catch (error) {
        Logger.warn('ContentSources.index.progress-listener-failed', {
          folder,
          error: String(error?.message || error)
        });
      }
    };
    emit({ folder, count: 0, batchCount: 0 });
    const records = [];
    checkAbort();
    await dataService[streamMethod](folder, async (batch) => {
      if (!Array.isArray(batch) || !batch.length) return;
      records.push(...batch);
      emit({ folder, count: records.length, batchCount: batch.length });
    }, { batchSize, sleepMs, signal });
    checkAbort();
    await dataService[saveMethod](folder, records);
    return { count: records.length };
  };
}

/**
 * BaseContentSourcesDialog
 * - Generic multi-folder selector with enable/disable, edit, remove, and custom label support
 * - Persists into a settings key under the 'fa-nexus' namespace
 */
export class BaseContentSourcesDialog extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    tag: 'form',
    window: { frame: true, positioned: true, resizable: true, title: 'Folder Selection' },
    position: { width: 630, height: 700 }
  };
  /**
   * @param {object} options
   * @param {string} options.id - application id
   * @param {string} options.title - window title
   * @param {string} options.settingsKey - settings key under 'fa-nexus' namespace
   * @param {{pluralNoun:string,emptyState:string}} options.presentation - feature-specific UI language
   */
  constructor({ id, title, settingsKey, presentation, cacheType = null, indexer = null, cloudConfig = null } = {}) {
    super({ id, window: { title: title || 'Folder Selection' } });
    this.folders = [];
    this._handlers = {};
    this._settingsKey = settingsKey;
    this._presentation = presentation;
    this._cacheType = cacheType;
    this._cacheDb = null;
    this._indexRunner = typeof indexer === 'function' ? indexer : null;
    this._indexManager = new ContentSourcesIndexer({
      runIndex: this._indexRunner,
      normalizePath: (value) => this._normalizePath(value),
      listeners: [(folder, state) => this._handleIndexStateChange(folder, state)]
    });
    this._initializePromise = null;
    this._initializationError = null;
    this._initialized = false;
    this._renderTimer = null;
    this._pendingScrollTop = null;
    this._lastScrollTop = 0;
    this._cacheEntries = [];
    this._cacheNeedsRefresh = !!cacheType;
    this._cacheFetchPromise = null;
    this._cacheFetchToken = 0;
    this._cloudConfig = this._normalizeCloudConfig(cloudConfig);
    this._cloudContext = null;
    this._cloudCacheMeta = this._buildCloudCacheMeta(this._cloudConfig);
    this._cloudEnabledSetting = this._cloudConfig?.setting || null;
    this._cloudToggleId = `${this.id}-cloud-toggle`;
    this._cloudInitialEnabled = null;
    this._cloudPendingEnabled = null;
    this._indexControllers = new Map();
    this._beginInitialization();
    if (this._cloudConfig) void this._loadCloudMeta();
  }

  static PARTS = {
    form: { template: CONTENT_SOURCES_TEMPLATE }
  };

  _beginInitialization() {
    this._initializationError = null;
    this._initialized = false;
    this._initializePromise = this.initialize()
      .then(() => {
        this._initialized = true;
        return true;
      })
      .catch((error) => {
        this._initializationError = error;
        this._initialized = false;
        throw error;
      });
  }

  async _ensureInitialized() {
    if (this._initialized) return true;
    if (this._initializationError) throw this._initializationError;
    if (!this._initializePromise) this._beginInitialization();
    return this._initializePromise;
  }

  async initialize() {
    if (!this._settingsKey) {
      this.folders = [];
      return;
    }
    try {
      const raw = game.settings.get('fa-nexus', this._settingsKey);
      this.folders = parseContentSourcesSetting(raw, { normalizePath: (value) => this._normalizePath(value) });
    } catch (error) {
      this.folders = [];
      Logger.error('ContentSources.initialize:failed', { key: this._settingsKey, error });
      if (ui?.notifications?.error) {
        ui.notifications.error('Failed to load content source settings.');
      }
      throw error;
    }
  }

  /** Bind dynamic events after render */
  _onRender(context, options) {
    super._onRender(context, options);
    this._bindEvents();
    this._restoreScrollPosition();
  }

  /** Unbind events on close */
  _onClose(options = {}) {
    this._cancelAllIndexing('close');
    try { this._indexManager?.dispose?.(); } catch (error) { Logger.warn('ContentSources.close:dispose-failed', { error }); }
    this._indexManager = null;
    this._clearRenderTimer();
    this._unbindEvents();
    this._cloudPendingEnabled = null;
    this._cloudInitialEnabled = null;
    this._cloudContext = null;
    super._onClose(options);
  }

  /**
   * Provide template context data
   * @returns {Promise<{folders:Array,hasFolders:boolean,enabledCount:number,totalCount:number}>}
   */
  async _prepareContext() {
    await this._ensureInitialized();
    const enabledCount = this.folders.filter(f => f.enabled).length;
    const totalCount = this.folders.length;
    const cacheEntries = await this._getCacheEntries();

    const cacheMap = {};
    let cacheTotalCount = 0;
    for (const entry of cacheEntries) {
      const folder = entry?.folder;
      if (!folder) continue;
      const count = Number(entry?.count || 0);
      cacheMap[folder] = (cacheMap[folder] || 0) + count;
      cacheTotalCount += count;
    }

    const normalizedFolders = new Set(this.folders.map((folder) => this._normalizePath(folder.path)));

    const orphanCaches = [];
    if (this._cacheType) {
      for (const entry of cacheEntries) {
        const folder = entry?.folder;
        if (!folder) continue;
        const normalized = this._normalizePath(folder);
        if (!normalizedFolders.has(normalized)) orphanCaches.push(entry);
      }
    }

    const folders = this.folders.map((folder) => {
      const cacheCount = cacheMap[folder.path] || 0;
      const rawState = this._indexManager.getState(folder.path) || null;
      const indexState = this._buildIndexState(folder.path, rawState);
      return Object.assign({}, folder, {
        cacheCount,
        hasCache: cacheCount > 0,
        indexState,
        isIndexing: !!indexState?.isRunning,
        folderKey: this._folderKey(folder.path)
      });
    });

    const runningIndexes = this._indexManager.getStates().filter((state) => state?.status === 'running').length;
    const cloud = await this._buildCloudContext();

    return {
      presentation: this._presentation,
      cloud,
      hasCloud: !!cloud,
      folders,
      hasFolders: totalCount > 0,
      enabledCount,
      totalCount,
      cacheType: this._cacheType,
      hasAnyCache: cacheEntries.length > 0,
      cacheFolderCount: cacheEntries.length,
      cacheTotalCount,
      orphanCaches,
      orphanCacheCount: orphanCaches.length,
      hasOrphanCaches: orphanCaches.length > 0,
      canIndex: !!this._indexRunner,
      runningIndexCount: runningIndexes,
      hasRunningIndex: runningIndexes > 0
    };
  }

  /** Attach DOM event listeners for UI widgets */
  _bindEvents() {
    this._unbindEvents();
    const root = this.element; if (!root) return;
    this._handlers = { checkboxes: [], labels: [], removes: [], edits: [], clears: [], orphanClears: [], indexes: [], cloudToggle: null, cloudClear: null };

    const addBtn = root.querySelector('#fa-nexus-add-folder-btn');
    if (addBtn) {
      this._handlers.add = () => this._addFolder();
      addBtn.addEventListener('click', this._handlers.add);
    }

    root.querySelectorAll('.fa-nexus-folder-checkbox').forEach((cb, idx) => {
      const onCheckboxChange = (ev) => {
        const target = ev.currentTarget || ev.target;
        const i = Number(target?.dataset?.index);
        this._toggleEnabled(i, target?.checked);
      };
      this._handlers.checkboxes[idx] = onCheckboxChange;
      cb.addEventListener('change', onCheckboxChange);
    });

    root.querySelectorAll('.fa-nexus-folder-label').forEach((label, idx) => {
      const onLabelClick = (ev) => {
        const target = ev.currentTarget || ev.target;
        const i = Number(target?.dataset?.index);
        this._editLabel(i);
      };
      this._handlers.labels[idx] = onLabelClick;
      label.addEventListener('click', onLabelClick);
    });

    root.querySelectorAll('.fa-nexus-remove-folder-btn').forEach((btn, idx) => {
      const onRemoveClick = async (ev) => {
        const target = ev.currentTarget || ev.target;
        const i = Number(target?.dataset?.index);
        await this._removeFolder(i);
      };
      this._handlers.removes[idx] = onRemoveClick;
      btn.addEventListener('click', onRemoveClick);
    });

    root.querySelectorAll('.fa-nexus-edit-folder-btn').forEach((btn, idx) => {
      const onEditClick = async (ev) => {
        const target = ev.currentTarget || ev.target;
        const i = Number(target?.dataset?.index);
        await this._editFolder(i);
      };
      this._handlers.edits[idx] = onEditClick;
      btn.addEventListener('click', onEditClick);
    });

    if (this._indexRunner) {
      root.querySelectorAll('.fa-nexus-index-folder-btn').forEach((btn, idx) => {
        const onIndexButtonClick = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          const el = ev.currentTarget || btn;
          const folder = el?.dataset?.folder || ev.target?.dataset?.folder;
          if (!folder) return;
          const action = (el?.dataset?.action || 'start').toLowerCase();
          if (action === 'cancel') await this._handleCancelIndex(folder, el);
          else await this._handleIndexFolder(folder, el);
        };
        this._handlers.indexes[idx] = onIndexButtonClick;
        btn.addEventListener('click', onIndexButtonClick);
      });
    }

    if (this._cacheType) {
      root.querySelectorAll('.fa-nexus-clear-cache-btn').forEach((btn, idx) => {
        const onClearCacheClick = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          const folder = ev.currentTarget?.dataset?.folder || ev.target?.dataset?.folder;
          if (!folder) return;
          await this._handleClearCache(folder, ev.currentTarget || btn);
        };
        this._handlers.clears[idx] = onClearCacheClick;
        btn.addEventListener('click', onClearCacheClick);
      });
      const clearAll = root.querySelector('#fa-nexus-clear-all-cache-btn');
      if (clearAll) {
        this._handlers.clearAll = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          await this._handleClearAllCaches(clearAll);
        };
        clearAll.addEventListener('click', this._handlers.clearAll);
      }
      const clearOrphan = root.querySelector('#fa-nexus-clear-orphan-cache-btn');
      if (clearOrphan) {
        this._handlers.clearOrphan = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          await this._handleClearOrphanCaches(clearOrphan);
        };
        clearOrphan.addEventListener('click', this._handlers.clearOrphan);
      }
      root.querySelectorAll('[data-action="clear-orphan-cache"]').forEach((btn, idx) => {
        const onClearOrphanClick = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          const folder = ev.currentTarget?.dataset?.folder || ev.target?.dataset?.folder;
          if (!folder) return;
          await this._handleClearCache(folder, ev.currentTarget || btn);
        };
        this._handlers.orphanClears[idx] = onClearOrphanClick;
        btn.addEventListener('click', onClearOrphanClick);
      });
    }

    const cloudCtx = this._cloudContext;
    if (cloudCtx?.toggleId && this._getCloudConfig()) {
      const cloudToggle = root.querySelector(`#${cloudCtx.toggleId}`);
      if (cloudToggle) {
        this._handlers.cloudToggle = async (ev) => {
          ev.preventDefault();
          await this._toggleCloudEnabled(ev.currentTarget || cloudToggle);
        };
        cloudToggle.addEventListener('change', this._handlers.cloudToggle);
      }
    }

    if (cloudCtx && this._getCloudConfig()) {
      const clearBtn = root.querySelector('.fa-nexus-cloud-clear-btn');
      if (clearBtn) {
        this._handlers.cloudClear = async (ev) => {
          ev.preventDefault(); ev.stopPropagation();
          await this._handleClearCloudIndexes(ev.currentTarget || clearBtn);
        };
        clearBtn.addEventListener('click', this._handlers.cloudClear);
      }
    }

    const saveBtn = root.querySelector('#fa-nexus-save-folders-btn');
    if (saveBtn) {
      this._handlers.save = () => this._save();
      saveBtn.addEventListener('click', this._handlers.save);
    }
    const cancelBtn = root.querySelector('#fa-nexus-cancel-folders-btn');
    if (cancelBtn) {
      this._handlers.cancel = () => this.close();
      cancelBtn.addEventListener('click', this._handlers.cancel);
    }
  }

  /** Detach DOM event listeners */
  _unbindEvents() {
    const root = this.element; if (!root) return;
    root.querySelector('#fa-nexus-add-folder-btn')?.removeEventListener('click', this._handlers.add);
    root.querySelector('#fa-nexus-save-folders-btn')?.removeEventListener('click', this._handlers.save);
    root.querySelector('#fa-nexus-cancel-folders-btn')?.removeEventListener('click', this._handlers.cancel);
    root.querySelectorAll('.fa-nexus-folder-checkbox').forEach((cb, idx) => cb.removeEventListener('change', this._handlers.checkboxes?.[idx]));
    root.querySelectorAll('.fa-nexus-folder-label').forEach((el, idx) => el.removeEventListener('click', this._handlers.labels?.[idx]));
    root.querySelectorAll('.fa-nexus-remove-folder-btn').forEach((el, idx) => el.removeEventListener('click', this._handlers.removes?.[idx]));
    root.querySelectorAll('.fa-nexus-edit-folder-btn').forEach((el, idx) => el.removeEventListener('click', this._handlers.edits?.[idx]));
    if (this._cacheType) {
      root.querySelectorAll('.fa-nexus-clear-cache-btn').forEach((el, idx) => el.removeEventListener('click', this._handlers.clears?.[idx]));
      root.querySelector('#fa-nexus-clear-all-cache-btn')?.removeEventListener('click', this._handlers.clearAll);
      root.querySelector('#fa-nexus-clear-orphan-cache-btn')?.removeEventListener('click', this._handlers.clearOrphan);
      root.querySelectorAll('[data-action="clear-orphan-cache"]').forEach((el, idx) => el.removeEventListener('click', this._handlers.orphanClears?.[idx]));
    }
    if (this._indexRunner) {
      root.querySelectorAll('.fa-nexus-index-folder-btn').forEach((el, idx) => el.removeEventListener('click', this._handlers.indexes?.[idx]));
    }
    if (this._handlers.cloudToggle && this._cloudContext?.toggleId) {
      root.querySelector(`#${this._cloudContext.toggleId}`)?.removeEventListener('change', this._handlers.cloudToggle);
    }
    if (this._handlers.cloudClear) {
      root.querySelector('.fa-nexus-cloud-clear-btn')?.removeEventListener('click', this._handlers.cloudClear);
    }
    this._clearRenderTimer();
    this._handlers = {};
  }

  _captureScrollPosition() {
    const list = this.element?.querySelector('.fa-nexus-folder-items');
    if (!list) return;
    const current = list.scrollTop;
    this._lastScrollTop = current;
    if (this._pendingScrollTop == null) this._pendingScrollTop = current;
  }

  _clearRenderTimer() {
    if (this._renderTimer) {
      clearTimeout(this._renderTimer);
      this._renderTimer = null;
    }
  }

  _restoreScrollPosition() {
    const target = this._pendingScrollTop != null ? this._pendingScrollTop : this._lastScrollTop;
    if (target == null) return;
    const list = this.element?.querySelector('.fa-nexus-folder-items');
    if (list) list.scrollTop = target;
    this._pendingScrollTop = null;
  }

  _requestRender({ preserveScroll = false, immediate = false } = {}) {
    if (preserveScroll) this._captureScrollPosition();
    if (immediate) {
      this._clearRenderTimer();
      this.render();
      return;
    }
    if (this._renderTimer) return;
    this._renderTimer = setTimeout(() => {
      this._renderTimer = null;
      this.render();
    }, 80);
  }

  _normalizePath(path) {
    return normalizeContentSourcePath(path);
  }

  _normalizePickedFolderPath(path, filePicker) {
    return normalizePickedFolderPath(path, filePicker, {
      normalizePath: (value) => this._normalizePath(value)
    });
  }

  _labelForFolderPath(path) {
    const str = String(path ?? '').trim();
    if (!str) return '';
    const scheme = str.match(/^([^:]+:)(.*)$/);
    if (!scheme) return str.split('/').pop() || str;
    const tail = String(scheme[2] || '').replace(/^\/+/, '');
    const last = tail.split('/').filter(Boolean).pop();
    return last || tail || str;
  }

  _folderKey(path) {
    return contentSourceKey(path);
  }

  _normalizeCloudConfig(config) {
    if (!config) return null;
    const requestedKind = config.kind || config.store || null;
    const descriptor = requestedKind ? getContentKindDescriptor(requestedKind) : null;
    const kind = descriptor?.kind || requestedKind || null;
    const store = config.store || kind;
    const progressBatch = Number.isFinite(config.progressBatch) ? Number(config.progressBatch) : 500;
    return Object.assign({}, config, {
      kind,
      store,
      db: config.db || descriptor?.dbName || null,
      metaFolder: config.metaFolder || config.id || 'cloud',
      progressBatch
    });
  }

  _buildCloudCacheMeta(config, meta = {}) {
    return {
      count: Number(meta.count) || 0,
      folder: meta.folder || config?.metaFolder || config?.id || 'cloud',
      latest: meta.latest || null
    };
  }

  _updateCloudCacheMeta(config, meta = {}) {
    this._cloudCacheMeta = this._buildCloudCacheMeta(config, meta);
    this._applyCloudCacheMetaToContext();
  }

  _applyCloudCacheMetaToContext() {
    if (!this._cloudContext) return;
    this._cloudContext.cacheCount = this._cloudCacheMeta.count;
    this._cloudContext.hasCache = this._cloudCacheMeta.count > 0;
    this._cloudContext.version = this._cloudCacheMeta.latest || this._cloudContext.version || null;
  }

  _pathsEqual(a, b) {
    return this._normalizePath(a) === this._normalizePath(b);
  }

  _isDuplicatePath(path, ignoreIndex = -1) {
    return this.folders.some((folder, idx) => idx !== ignoreIndex && this._pathsEqual(folder.path, path));
  }

  /** Ensure cache database instance is available */
  async _ensureCacheDb() {
    if (!this._cacheType) return null;
    if (!this._cacheDb) {
      try {
        const { NexusIndexDB } = await import('../cache-index.js');
        this._cacheDb = new NexusIndexDB('fa-nexus-index');
      } catch (error) {
        Logger.error('Folders.cache:db-failed', error);
        if (ui?.notifications?.error) ui.notifications.error('Unable to access cached indexes.');
        return null;
      }
    }
    return this._cacheDb;
  }

  /** Retrieve cached index metadata for current type */
  async _getCacheEntries() {
    if (!this._cacheType) return [];
    if (!this._cacheNeedsRefresh && Array.isArray(this._cacheEntries)) return this._cacheEntries;
    if (!this._cacheFetchPromise) {
      const token = ++this._cacheFetchToken;
      this._cacheFetchPromise = this._fetchCacheEntries()
        .then((entries) => {
          if (token === this._cacheFetchToken) {
            this._cacheEntries = entries;
            this._cacheNeedsRefresh = false;
          }
          return entries;
        })
        .catch((error) => {
          Logger.error('Folders.cache:fetch-failed', error);
          return [];
        })
        .finally(() => {
          if (this._cacheFetchToken === token) {
            this._cacheFetchPromise = null;
          }
        });
    }
    return this._cacheFetchPromise;
  }

  async _fetchCacheEntries() {
    try {
      const db = await this._ensureCacheDb();
      if (!db) return [];
      const entries = await db.list(this._cacheType);
      return Array.isArray(entries) ? entries : [];
    } catch (error) {
      Logger.error('Folders.cache:list-failed', error);
      return [];
    }
  }

  async _handleClearCache(folder, button = null, { showNotification = true, refresh = true } = {}) {
    const db = await this._ensureCacheDb();
    if (!db || !folder) return false;
    const original = button?.innerHTML;
    if (button) {
      button.disabled = true;
      button.setAttribute('data-loading', 'true');
      button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    if (refresh) this._captureScrollPosition();
    try {
      const cleared = await db.clear(this._cacheType, folder);
      if (cleared) {
        this._markCacheDirty();
        if (showNotification && ui?.notifications?.info) ui.notifications.info(`Cleared cached index for ${folder}`);
      } else {
        if (showNotification && ui?.notifications?.warn) ui.notifications.warn(`No cached index found for ${folder}`);
      }
      return cleared;
    } catch (error) {
      Logger.error('Folders.cache:clear-failed', { folder, error });
      if (showNotification && ui?.notifications?.error) ui.notifications.error('Failed to clear cached index.');
      return false;
    } finally {
      if (button) {
        button.disabled = false;
        button.removeAttribute('data-loading');
        if (original) button.innerHTML = original;
      }
      if (refresh) this._requestRender({ preserveScroll: true, immediate: true });
    }
  }

  async _handleClearAllCaches(button) {
    const db = await this._ensureCacheDb();
    if (!db) return;
    const original = button?.innerHTML;
    if (button) {
      button.disabled = true;
      button.setAttribute('data-loading', 'true');
      button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    this._captureScrollPosition();
    try {
      await db.clearAll(this._cacheType);
      this._markCacheDirty();
      if (ui?.notifications?.info) ui.notifications.info(`Cleared all cached ${this._cacheType} indexes.`);
    } catch (error) {
      Logger.error('Folders.cache:clear-all-failed', error);
      if (ui?.notifications?.error) ui.notifications.error('Failed to clear cached indexes.');
    } finally {
      if (button) {
        button.disabled = false;
        button.removeAttribute('data-loading');
        if (original) button.innerHTML = original;
      }
      this._requestRender({ preserveScroll: true, immediate: true });
    }
  }

  async _handleClearOrphanCaches(button) {
    const db = await this._ensureCacheDb();
    if (!db || !this._cacheType) return;
    const original = button?.innerHTML;
    if (button) {
      button.disabled = true;
      button.setAttribute('data-loading', 'true');
      button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    this._captureScrollPosition();
    try {
      const entries = await db.list(this._cacheType);
      const known = new Set(this.folders.map((f) => this._normalizePath(f.path)));
      for (const entry of entries) {
        if (!entry?.folder) continue;
        if (known.has(this._normalizePath(entry.folder))) continue;
        await db.clear(this._cacheType, entry.folder);
      }
      this._markCacheDirty();
      if (ui?.notifications?.info) ui.notifications.info('Cleared cached indexes for folders no longer tracked.');
    } catch (error) {
      Logger.error('Folders.cache:clear-orphan-failed', error);
      if (ui?.notifications?.error) ui.notifications.error('Failed to clear unlisted cached indexes.');
    } finally {
      if (button) {
        button.disabled = false;
        button.removeAttribute('data-loading');
        if (original) button.innerHTML = original;
      }
      this._requestRender({ preserveScroll: true, immediate: true });
    }
  }

  async _handleIndexFolder(folder, button) {
    const cloudConfig = this._getCloudConfig();
    if (cloudConfig && this._pathsEqual(folder, cloudConfig.id)) {
      return this._handleIndexCloud(button);
    }
    if (!this._indexRunner || !this._indexManager || !folder) return;
    if (button) button.disabled = true;
    this._captureScrollPosition();
    try {
      const state = await this._indexManager.start(folder, { onBeforeStart: () => this._captureScrollPosition() });
      if (state?.status === 'done') {
        const count = Number.isFinite(state.count) ? Number(state.count) : 0;
        this._markCacheDirty();
        this._requestRender({ immediate: true, preserveScroll: true });
        if (ui?.notifications?.info) ui.notifications.info(`Indexed ${count} item(s) for ${folder}`);
      } else if (state?.status === 'cancelled') {
        this._requestRender({ immediate: true, preserveScroll: true });
      }
    } catch (error) {
      const cause = error?.cause || error;
      if (cause?.name !== 'AbortError') {
        Logger.error('ContentSources.index:failed', { folder, error: cause });
        if (ui?.notifications?.error) ui.notifications.error(`Failed to index folder: ${folder}`);
      }
      this._requestRender({ immediate: true, preserveScroll: true });
    } finally {
      if (button && button.isConnected) button.disabled = false;
    }
  }

  async _handleIndexCloud(button) {
    const cloudConfig = this._getCloudConfig();
    if (!cloudConfig?.store) return;

    const folder = cloudConfig.id || 'cloud';
    const normalized = this._normalizePath(folder);
    if (this._indexControllers.has(normalized)) return;

    const controller = new AbortController();
    this._indexControllers.set(normalized, controller);

    this._captureScrollPosition();
    this._renderIndexState(folder, { status: 'running', phase: 'preparing', count: 0, error: null, startedAt: Date.now() });

    const emitProgress = (info = {}) => {
      const count = Number.isFinite(info?.count) ? Number(info.count) : 0;
      this._renderIndexState(folder, {
        status: 'running',
        phase: info?.phase || null,
        count: Math.max(0, count),
        updatedAt: Date.now()
      });
    };

    try {
      await this._beforeCloudIndex?.(cloudConfig);
      const svc = await this._createCloudContentService();
      await svc.sync(cloudConfig.store, {
        forceFull: true,
        signal: controller.signal,
        onManifestProgress: emitProgress,
        progressBatch: cloudConfig.progressBatch
      });

      const meta = await svc.getMeta(cloudConfig.store);
      const finalCount = Number(meta?.count) || 0;
      if (meta) {
        this._updateCloudCacheMeta(cloudConfig, {
          count: finalCount,
          folder: cloudConfig.metaFolder,
          latest: meta.latest || null
        });
        this._renderCloudRow();
      }

      this._renderIndexState(folder, { status: 'done', count: finalCount, finishedAt: Date.now(), error: null });
      await this._afterCloudIndexed?.(cloudConfig);
      this._markCacheDirty();
      this._captureScrollPosition();
      this._requestRender({ immediate: true, preserveScroll: true });
      const itemLabel = cloudConfig.itemLabel || 'item';
      if (ui?.notifications?.info) ui.notifications.info(`Indexed ${finalCount} cloud ${itemLabel}(s)`);
    } catch (error) {
      if (controller.signal.aborted || error?.name === 'AbortError') {
        this._renderIndexState(folder, { status: 'cancelled', finishedAt: Date.now() });
      } else {
        Logger.error('Folders.cloud.index:failed', error);
        this._renderIndexState(folder, { status: 'error', error: error?.message || String(error), finishedAt: Date.now() });
        const message = cloudConfig.indexFailureMessage || 'Failed to index cloud content.';
        if (ui?.notifications?.error) ui.notifications.error(message);
      }
      this._captureScrollPosition();
      this._requestRender({ immediate: true, preserveScroll: true });
    } finally {
      this._indexControllers.delete(normalized);
      if (button && button.isConnected) button.disabled = false;
    }
  }

  async _handleCancelIndex(folder, button) {
    if (!folder) return;
    if (button) button.disabled = true;
    const controller = this._indexControllers?.get?.(this._normalizePath(folder));
    if (controller) {
      controller.abort('user-cancelled');
      return;
    }
    if (!this._indexManager) return;
    this._indexManager.cancel(folder, 'user-cancelled');
  }

  _handleIndexStateChange(folder, state) {
    this._renderIndexState(folder, state);
  }

  _buildIndexState(folder, state) {
    if (!state) return { folder, status: 'idle', count: 0, isRunning: false, icon: '', text: '', css: '', expireAt: null };
    const status = state.status || 'idle';
    const count = Number.isFinite(state.count) ? Number(state.count) : 0;
    const expireAt = state.expireAt || null;
    if (expireAt && Date.now() > expireAt && status !== 'running') {
      return { folder, status: 'idle', count, isRunning: false, icon: '', text: '', css: '', expireAt: null };
    }
    const info = { ...state, folder, status, count, isRunning: status === 'running', expireAt };
    let icon = '';
    let text = '';
    let css = '';
    if (status === 'running') {
      icon = 'fa-spinner fa-spin';
      if (state.phase === 'preparing') text = 'Preparing cloud index…';
      else if (state.phase === 'waiting') text = 'Waiting for current cloud index…';
      else if (state.phase === 'download') text = 'Downloading cloud index…';
      else if (state.phase === 'replaceAll' && count === 0) text = 'Preparing cloud index…';
      else text = `Indexing… ${count}`;
      css = 'is-running';
    } else if (status === 'done') {
      icon = 'fa-check';
      text = count ? `Indexed ${count} item(s)` : 'Index updated';
      css = 'is-done';
    } else if (status === 'error') {
      icon = 'fa-exclamation-triangle';
      text = state.error || 'Index failed';
      css = 'is-error';
    } else if (status === 'cancelled') {
      icon = 'fa-ban';
      text = 'Index cancelled';
      css = 'is-cancelled';
    } else if (count) {
      icon = 'fa-check';
      text = `Last indexed ${count} item(s)`;
      css = 'is-complete';
    }
    return Object.assign(info, { icon, text, css, expireAt });
  }

  _cancelAllIndexing(reason = 'cancelled') {
    for (const controller of this._indexControllers.values()) {
      if (!controller.signal.aborted) controller.abort(reason);
    }
    this._indexManager?.cancelAll(reason);
  }

  _cancelIndexFor(folder, reason = 'cancelled') {
    if (!this._indexManager || !folder) return;
    this._indexManager.cancel(folder, reason);
  }

  _findFolderRow(folder) {
    const root = this.element;
    if (!root || !folder) return null;
    const key = this._folderKey(folder);
    if (!key) return null;
    return root.querySelector(`.fa-nexus-folder-item[data-folder-key="${key}"]`);
  }

  _renderIndexState(folder, state = null) {
    if (!folder) return;
    const row = this._findFolderRow(folder);
    if (!row) return;
    const currentState = state ?? this._indexManager?.getState(folder) ?? null;
    const view = this._buildIndexState(folder, currentState);
    const info = row.querySelector('.fa-nexus-folder-info');
    if (!info) return;

    let statusEl = info.querySelector('.fa-nexus-folder-index-status');
    if (!view || !view.text) {
      if (statusEl) statusEl.remove();
    } else {
      if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.className = 'fa-nexus-folder-index-status';
        info.appendChild(statusEl);
      }
      const classes = ['fa-nexus-folder-index-status'];
      if (view.css) classes.push(view.css);
      statusEl.className = classes.join(' ');
      const icon = view.icon || 'fa-info-circle';
      setIconTextContent(statusEl, icon, view.text);
    }

    const indexBtn = row.querySelector('.fa-nexus-index-folder-btn');
    if (indexBtn) {
      if (view?.isRunning) {
        indexBtn.disabled = false;
        indexBtn.dataset.action = 'cancel';
        indexBtn.classList.add('is-cancel');
        setIconOnlyContent(indexBtn, 'fa-ban');
        indexBtn.title = 'Cancel indexing';
      } else {
        indexBtn.disabled = false;
        indexBtn.dataset.action = 'start';
        indexBtn.classList.remove('is-cancel');
        setIconOnlyContent(indexBtn, 'fa-sync-alt');
        indexBtn.title = 'Rebuild index';
      }
    }
  }

  async _buildCloudContext() {
    const config = this._getCloudConfig();
    if (!config) {
      this._cloudContext = null;
      return null;
    }
    const enabledSetting = this._cloudPendingEnabled != null ? this._cloudPendingEnabled : this._getCloudEnabled(config);
    if (this._cloudInitialEnabled === null) this._cloudInitialEnabled = enabledSetting;
    const cacheCount = Number(config.cacheCount ?? this._cloudCacheMeta?.count ?? 0) || 0;
    const cloudId = config.id || 'cloud';
    const rawState = this._indexManager.getState(cloudId) || null;
    const indexState = this._buildIndexState(cloudId, rawState);
    const context = {
      id: cloudId,
      label: config.label || 'Cloud Library',
      description: config.description || '',
      icon: config.icon || 'fa-cloud',
      path: config.path || 'FA Nexus Cloud',
      version: config.version || this._cloudCacheMeta?.latest || null,
      setting: config.setting || this._cloudEnabledSetting,
      toggleId: config.toggleId || this._cloudToggleId,
      folderKey: this._folderKey(cloudId),
      cacheCount,
      hasCache: cacheCount > 0,
      enabled: enabledSetting,
      isCloud: true,
      indexState
    };
    this._cloudContext = context;
    return context;
  }

  _getCloudConfig() {
    if (!this._cloudConfig) return null;
    return Object.assign({}, this._cloudConfig, {
      cacheCount: this._cloudCacheMeta?.count ?? this._cloudConfig.cacheCount ?? 0,
      version: this._cloudCacheMeta?.latest || this._cloudConfig.version || null
    });
  }

  async _createCloudContentService() {
    const { NexusContentService } = await import('../nexus-content-service.js');
    const app = foundry?.applications?.instances?.get?.('fa-nexus-app') || null;
    const authProvider = (app && typeof app._getAuthService === 'function') ? () => app._getAuthService() : undefined;
    return new NexusContentService({ app, authService: authProvider });
  }

  async _loadCloudMeta() {
    const config = this._getCloudConfig();
    if (!config?.store) return;
    try {
      const svc = await this._createCloudContentService();
      const meta = await svc.getMeta(config.store);
      if (!meta) return;
      this._updateCloudCacheMeta(config, {
        count: Number(meta.count) || 0,
        folder: config.metaFolder,
        latest: meta.latest || null
      });
      if (this.rendered) this._renderCloudRow();
    } catch (error) {
      Logger.warn(config.metaFailureLogTag || 'ContentSources.cloudMeta.loadFailed', {
        setting: config.setting,
        store: config.store,
        error: String(error?.message || error)
      });
    }
  }

  _getCloudEnabled(config) {
    return readFaNexusCloudEnabledSetting({
      setting: config?.setting,
      warningKey: 'ContentSources.cloudEnabled.readFailed',
      context: {
        setting: config?.setting,
        kind: config?.kind,
        store: config?.store
      }
    });
  }

  async _setCloudEnabled(enabled) {
    const config = this._getCloudConfig();
    if (!config?.setting) return;
    await game.settings.set('fa-nexus', config.setting, !!enabled);
  }

  async _toggleCloudEnabled(toggle) {
    const config = this._getCloudConfig();
    if (!config) return;
    const checkbox = toggle;
    const desired = !!checkbox?.checked;
    if (this._cloudContext) this._cloudContext.enabled = desired;
    if (this._cloudInitialEnabled != null && desired === this._cloudInitialEnabled) {
      this._cloudPendingEnabled = null;
    } else {
      this._cloudPendingEnabled = desired;
    }
    this._renderCloudRow();
  }

  _renderCloudRow(context = this._cloudContext) {
    const root = this.element;
    if (!root || !context) return;
    const row = root.querySelector(`.fa-nexus-cloud-row[data-folder-key="${context.folderKey}"]`);
    if (!row) return;
    row.classList.toggle('fa-nexus-folder-disabled', !context.enabled);
    const toggle = row.querySelector(`#${context.toggleId}`);
    if (toggle) toggle.checked = !!context.enabled;
    const cacheWrap = row.querySelector('.fa-nexus-folder-cache');
    if (cacheWrap) {
      cacheWrap.classList.toggle('is-present', context.cacheCount > 0);
      cacheWrap.classList.toggle('is-empty', context.cacheCount <= 0);
      const span = cacheWrap.querySelector('span');
      if (span) span.textContent = `${context.cacheCount} item(s)`;
    }
  }

  async _handleClearCloudIndexes(button) {
    const config = this._getCloudConfig();
    if (!config?.db || !config?.store) return;
    const original = button?.innerHTML;
    if (button) {
      button.disabled = true;
      button.setAttribute('data-loading', 'true');
      button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    try {
      const { CloudDB } = await import('../cloud-db.js');
      const db = new CloudDB(config.db);
      await db.clear(config.store);
      await this._afterCloudIndexCleared?.(config);
      this._cloudCacheMeta = { ...this._cloudCacheMeta, count: 0, latest: null };
      if (this._cloudContext) {
        this._cloudContext.cacheCount = 0;
        this._cloudContext.hasCache = false;
        this._cloudContext.version = null;
      }
      this._renderCloudRow();
      if (ui?.notifications?.info) ui.notifications.info(`Cleared ${config.label || 'cloud'} index`);
    } catch (error) {
      Logger.error('Folders.cloud.clear:failed', error);
      if (ui?.notifications?.error) ui.notifications.error('Failed to clear cloud index.');
    } finally {
      if (button) {
        button.disabled = false;
        button.removeAttribute('data-loading');
        if (original) button.innerHTML = original;
      }
    }
  }

  _markCacheDirty() {
    if (!this._cacheType) return;
    this._cacheNeedsRefresh = true;
    this._cacheFetchToken += 1;
    this._cacheFetchPromise = null;
  }

  /** Open a FilePicker to add a new folder entry */
  async _addFolder() {
    Logger.info('Folders.add:open');
    const FilePickerClass = getFilePickerClass();
    if (!FilePickerClass) {
      if (ui?.notifications?.warn) ui.notifications.warn('Unable to open file storage; FilePicker is unavailable.');
      return;
    }
    const fp = new FilePickerClass({
      type: 'folder', title: 'Select Folder',
      callback: (path) => {
        path = this._normalizePickedFolderPath(path, fp);
        const label = this._labelForFolderPath(path);
        if (this._isDuplicatePath(path)) {
          if (ui?.notifications?.warn) ui.notifications.warn('That folder has already been added.');
          return;
        }
        this.folders.push({ path, label, enabled: true, customLabel: null });
        Logger.info('Folders.add:done', { path });
        this._requestRender({ preserveScroll: true });
      }
    });
    const context = await prepareFolderPickerContext(fp, {
      useCurrentContext: true,
      logger: Logger,
      loggerTag: 'Folders.add'
    });
    const opened = await browseFolderPickerWithFallbacks(fp, {
      context,
      logger: Logger,
      loggerTag: 'Folders.add'
    });
    if (opened?.opened) return;
    if (ui?.notifications?.warn) ui.notifications.warn('Unable to open file storage; please configure your Forge buckets.');
  }

  /** Toggle enabled state for a folder row */
  _toggleEnabled(index, enabled) {
    if (index >= 0 && index < this.folders.length) {
      this.folders[index].enabled = !!enabled;
      this._requestRender({ preserveScroll: true });
    }
  }

  /** Open a FilePicker to edit an existing folder path */
  async _editFolder(index) {
    const existing = this.folders[index];
    if (!existing) return;
    Logger.info('Folders.edit:open', { index, existing });
    const FilePickerClass = getFilePickerClass();
    if (!FilePickerClass) {
      if (ui?.notifications?.warn) ui.notifications.warn('Unable to open file storage; FilePicker is unavailable.');
      return;
    }
    const fp = new FilePickerClass({
      type: 'folder', title: 'Select Folder',
      callback: async (path) => {
        path = this._normalizePickedFolderPath(path, fp);
        const label = this._labelForFolderPath(path);
        if (this._isDuplicatePath(path, index)) {
          if (ui?.notifications?.warn) ui.notifications.warn('That folder has already been added.');
          return;
        }
        const previousPath = existing.path;
        this.folders[index] = { ...existing, path, label };
        Logger.info('Folders.edit:done', { index, path });
        if (path !== previousPath) {
          this._cancelIndexFor(previousPath, 'folder-edited');
          if (this._cacheType) {
            await this._handleClearCache(previousPath, null, { showNotification: false, refresh: false });
          }
        }
        this._requestRender({ preserveScroll: true });
      }
    });
    const context = await prepareFolderPickerContext(fp, {
      folder: existing.path,
      logger: Logger,
      loggerTag: 'Folders.edit'
    });
    const opened = await browseFolderPickerWithFallbacks(fp, {
      context,
      logger: Logger,
      loggerTag: 'Folders.edit'
    });
    if (opened?.opened) return;
    if (ui?.notifications?.warn) ui.notifications.warn('Unable to open file storage; please configure your Forge buckets.');
  }

  /** Inline-edit the label for a folder */
  _editLabel(index) {
    const folder = this.folders[index];
    if (!folder) return;
    Logger.debug('Folders.label:edit', { index, current: folder.customLabel || folder.label });
    const root = this.element;
    const labelEl = root?.querySelector(`[data-index="${index}"].fa-nexus-folder-label`);
    if (!labelEl) return;
    const current = folder.customLabel || folder.label;
    const input = document.createElement('input');
    input.type = 'text'; input.value = current; input.className = 'fa-nexus-folder-label-input';
    labelEl.innerHTML = ''; labelEl.appendChild(input);
    input.focus(); input.select();
    const save = () => {
      const v = (input.value || '').trim();
      folder.customLabel = v || null;
      this._requestRender({ preserveScroll: true });
    };
    const cancel = () => {
      this._requestRender({ preserveScroll: true });
    };
    input.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') { ev.preventDefault(); save(); }
      else if (ev.key === 'Escape') { ev.preventDefault(); cancel(); }
    });
    input.addEventListener('blur', save);
  }

  /** Remove a folder entry by index */
  async _removeFolder(index) {
    if (index >= 0 && index < this.folders.length) {
      const [removed] = this.folders.splice(index, 1);
      Logger.info('Folders.remove', { index });
      if (removed?.path) {
        this._cancelIndexFor(removed.path, 'folder-removed');
      }
      if (removed?.path && this._cacheType) {
        await this._handleClearCache(removed.path, null, { showNotification: false, refresh: false });
      }
      this._requestRender({ preserveScroll: true });
    }
  }

  /** Persist current folders to the configured settings key */
  async _save() {
    let previousPayload;
    let shouldUpdateCloud = false;
    let settingsSaved = false;
    let cloudConfig = null;
    try {
      await this._ensureInitialized();
      const payload = serializeContentSourcesSetting(this.folders, { normalizePath: (value) => this._normalizePath(value) });
      previousPayload = game.settings.get('fa-nexus', this._settingsKey);
      cloudConfig = this._getCloudConfig();
      const pending = this._cloudPendingEnabled;
      const initial = this._cloudInitialEnabled;
      const desired = (pending != null) ? pending : initial;
      shouldUpdateCloud = !!(cloudConfig?.setting && desired != null && desired !== initial);
      await game.settings.set('fa-nexus', this._settingsKey, payload);
      settingsSaved = true;
      if (shouldUpdateCloud) {
        await this._setCloudEnabled(desired);
      }
      if (cloudConfig?.setting) {
        this._cloudInitialEnabled = desired;
        this._cloudPendingEnabled = null;
        if (this._cloudContext) {
          this._cloudContext.enabled = desired;
          this._renderCloudRow();
        }
      }
      Logger.info('Folders.save', { key: this._settingsKey, count: this.folders.length });
      ui.notifications.info(`Saved ${this.folders.length} folder(s)`);
      this.close();
    } catch (e) {
      if (settingsSaved && shouldUpdateCloud) {
        try {
          await game.settings.set('fa-nexus', this._settingsKey, previousPayload);
        } catch (rollbackError) {
          Logger.error('Folders.save:rollback-failed', { key: this._settingsKey, setting: cloudConfig?.setting, error: rollbackError });
        }
      }
      Logger.error('Folders.save:failed', e);
      ui.notifications.error('Failed to save folder configuration');
    }
  }
}
